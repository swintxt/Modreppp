package net.cebularz.droppedbuffs;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Mod(modid = DroppedBuffs.MODID, name = "Dropped Buffs", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
@Mod.EventBusSubscriber(modid = DroppedBuffs.MODID)
public class DroppedBuffs {
    public static final String MODID = "droppedbuffs";

    /** Шанс выпадения в процентах (временно 100). */
    public static final int DROP_CHANCE = 100;
    /** Сколько секунд бафф лежит на земле. */
    public static final int GROUND_SECONDS = 20;
    /** Длительность эффекта в секундах. */
    public static final int EFFECT_SECONDS = 30;

    public static final List<BuffItem> BUFFS = new ArrayList<BuffItem>();
    private static final Random RAND = new Random();

    static {
        BUFFS.add(new BuffItem("strength_buff", MobEffects.STRENGTH, 0));
        BUFFS.add(new BuffItem("speed_buff", MobEffects.SPEED, 0));
        BUFFS.add(new BuffItem("haste_buff", MobEffects.HASTE, 0));
        BUFFS.add(new BuffItem("resistance_buff", MobEffects.RESISTANCE, 0));
        BUFFS.add(new BuffItem("fire_resistance_buff", MobEffects.FIRE_RESISTANCE, 0));
        BUFFS.add(new BuffItem("water_breathing_buff", MobEffects.WATER_BREATHING, 0));
        BUFFS.add(new BuffItem("night_vision_buff", MobEffects.NIGHT_VISION, 0));
        BUFFS.add(new BuffItem("invisibility_buff", MobEffects.INVISIBILITY, 0));
        BUFFS.add(new BuffItem("luck_buff", MobEffects.LUCK, 0));
        BUFFS.add(new BuffItem("absorption_buff", MobEffects.ABSORPTION, 1));
        BUFFS.add(new BuffItem("heal_buff", null, 0));   // лечение 
        BUFFS.add(new BuffItem("meat_buff", null, 0));   // еда
    }

    public static class BuffItem extends Item {
        public final Potion effect;
        public final int amplifier;

        public BuffItem(String name, Potion effect, int amplifier) {
            this.effect = effect;
            this.amplifier = amplifier;
            setRegistryName(MODID, name);
            setUnlocalizedName(MODID + "." + name);
            setCreativeTab(CreativeTabs.MISC);
        }

        public void apply(EntityPlayer p) {
            String n = getRegistryName().getResourcePath();
            if (n.equals("heal_buff")) {
                p.heal(8.0F);
            } else if (n.equals("meat_buff")) {
                p.getFoodStats().addStats(8, 6.0F / 8.0F);
            } else {
                p.addPotionEffect(new PotionEffect(effect, EFFECT_SECONDS * 20, amplifier));
            }
        }
    }

    @EventHandler
    public void preInit(FMLPreInitializationEvent e) {
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        for (BuffItem b : BUFFS) e.getRegistry().register(b);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void registerModels(ModelRegistryEvent e) {
        for (BuffItem b : BUFFS) {
            ModelLoader.setCustomModelResourceLocation(b, 0, new ModelResourceLocation(b.getRegistryName(), "inventory"));
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntityLiving().world.isRemote) return;
        if (!(e.getSource().getTrueSource() instanceof EntityPlayer)) return;
        if (RAND.nextInt(100) >= DROP_CHANCE) return;
        BuffItem b = BUFFS.get(RAND.nextInt(BUFFS.size()));
        EntityItem ent = new EntityItem(e.getEntityLiving().world,
                e.getEntityLiving().posX, e.getEntityLiving().posY + 0.5, e.getEntityLiving().posZ,
                new ItemStack(b));
        ent.lifespan = GROUND_SECONDS * 20;
        ent.setDefaultPickupDelay();
        e.getEntityLiving().world.spawnEntity(ent);
    }

    /** Подбор: применяем эффект и забираем предмет, в инвентарь он не попадает. */
    @SubscribeEvent
    public static void onPickup(EntityItemPickupEvent e) {
        ItemStack s = e.getItem().getItem();
        if (s.getItem() instanceof BuffItem) {
            if (!e.getEntityPlayer().world.isRemote) {
                ((BuffItem) s.getItem()).apply(e.getEntityPlayer());
            }
            s.setCount(0);
            e.setResult(Event.Result.ALLOW);
        }
    }
}
